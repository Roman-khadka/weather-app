<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "coursework";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the database connection
if ($conn->connect_error) {
    header('HTTP/1.1 500 Internal Server Error');
    die('Database connection error: ' . $conn->connect_error);
}

$sql_fetch = "SELECT * FROM example_table";
$result_fetch = $conn->query($sql_fetch);

$data_array = array();

if ($result_fetch) {
    // Add each row to the data array
    while ($row = $result_fetch->fetch_assoc()) {
        $data_array[] = array(
            'date' => $row["date"],
            'temperature' => $row["temperature"],
            'humidity' => $row["humidity"],
            'wind_speed' => $row["Wind_speed"]
        );
    }

    // Convert the data array to JSON
    $json_data = json_encode($data_array);

    if ($json_data !== false) {
        // Output the JSON data
        header('Content-Type: application/json');
        echo $json_data;
    } else {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('message' => 'Error encoding JSON'));
    }
} else {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('message' => 'Error executing SQL query'));
}

$conn->close();
?>