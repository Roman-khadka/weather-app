<?php
include_once('fetch.php');
$past_time = 1706161056;

function past() {
    global $past_time,$response;
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "coursework";

    $current_time = time();

   

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

   

    if (isset($response))$response = json_decode($response, true);

    if ($response === null) {
        echo "Error decoding JSON res$response";
        return;
    }

    if (!isset($response['main'], $response['wind'])) {
        echo "Error: Invalid res$response structure";
        return;
    }

    $date = date('Y-m-d H:i:s'); // current date and time
    $temperature = $response['main']['temp'];
    $humidity = $response['main']['humidity'];
    $wind_speed = $response['wind']['speed'];



    $sql = "INSERT INTO example_table (date, temperature, humidity, Wind_speed)
    VALUES ('$date', '$temperature', '$humidity', '$wind_speed')";


    if (mysqli_query($conn, $sql)) {
        echo "Record inserted successfully";
    } else {
        echo "Error inserting record: " . mysqli_error($conn);
    }

    $past_time = time();
}

past();
?>
