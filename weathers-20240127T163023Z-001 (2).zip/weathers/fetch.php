<?php

$city = '';

if (isset($_GET['city'])) {
    $city = $_GET['city'];
}
else {
    $city = "Christchurch";
}

$apiKey = "621abb6dcc0c5a6fa4f6715ce226589f";  

// Construct the API URL
$apiUrl = "https://api.openweathermap.org/data/2.5/weather?q=" . $city . "&units=metric&appid=" . $apiKey;

$response = file_get_contents($apiUrl);

echo $response;
?>